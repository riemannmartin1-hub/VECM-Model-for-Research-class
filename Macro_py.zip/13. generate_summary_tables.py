from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

matplotlib.use("Agg")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
PAPER_DIR = RESULTS_DIR / "paper_ready"
BACKTEST_DIR = PAPER_DIR / "backtest_results"
FUTURE_DIR = PAPER_DIR / "future_forecasts"

# Match the figure directories used by the forecast scripts
FIG_BACKTEST_DIR = RESULTS_DIR / "figures" / "paper_ready" / "backtest_results"
FIG_FUTURE_DIR = RESULTS_DIR / "figures" / "paper_ready" / "future_forecasts"

FIG_BACKTEST_DIR.mkdir(parents=True, exist_ok=True)
FIG_FUTURE_DIR.mkdir(parents=True, exist_ok=True)

CLEAN_DATA_PATH = DATA_DIR / "clean_data.csv"
BACKTEST_SERIES_PATH = BACKTEST_DIR / "backtest_forecast_series.csv"
BACKTEST_METRICS_PATH = BACKTEST_DIR / "table_backtest_metrics.csv"
FUTURE_SERIES_PATH = FUTURE_DIR / "future_forecast_series.csv"
PREF_PATH = PAPER_DIR / "table_country_preferred_spec.csv"

# ── colours ──────────────────────────────────────────────────────────────────
HEADER_BG   = "#1f4e79"
HEADER_FG   = "white"
ROW_ODD     = "#dce6f1"
ROW_EVEN    = "white"
BORDER      = "#1f4e79"
FONT_BODY   = 9
FONT_HEADER = 9


def save_table_figure(df: pd.DataFrame, title: str, out_path: Path,
                      col_labels: list[str] | None = None,
                      highlight_col: str | None = None) -> None:
    """Render *df* as a styled matplotlib table and save to *out_path*."""
    if col_labels is None:
        col_labels = list(df.columns)

    n_rows, n_cols = df.shape
    # Row height and col width scale with content
    row_h = 0.38
    fig_h = max(2.2, row_h * (n_rows + 1) + 0.9)   # +1 for header, +0.9 title
    fig_w = max(8, n_cols * 1.55)

    fig, ax = plt.subplots(figsize=(fig_w, fig_h))
    ax.set_axis_off()

    cell_text = []
    cell_colors = []

    for i, (_, row) in enumerate(df.iterrows()):
        base = ROW_ODD if i % 2 == 0 else ROW_EVEN
        row_vals = []
        row_colors = []
        for col in df.columns:
            val = row[col]
            row_vals.append(str(val))
            # Heat-colour the highlight column (growth %)
            if col == highlight_col and isinstance(val, (int, float)) and not np.isnan(val):
                if val > 0:
                    intensity = min(val / 20, 1.0)          # saturate at +20 %
                    r = 1.0 - 0.35 * intensity
                    g = 1.0 - 0.10 * intensity
                    b = 1.0 - 0.50 * intensity
                    row_colors.append((r, g, b))
                elif val < 0:
                    intensity = min(abs(val) / 15, 1.0)     # saturate at −15 %
                    row_colors.append((1.0, 1.0 - 0.45 * intensity, 1.0 - 0.45 * intensity))
                else:
                    row_colors.append(base)
            else:
                row_colors.append(base)
        cell_text.append(row_vals)
        cell_colors.append(row_colors)

    tbl = ax.table(
        cellText=cell_text,
        colLabels=col_labels,
        cellColours=cell_colors,
        cellLoc="center",
        loc="center",
    )
    tbl.auto_set_font_size(False)
    tbl.set_fontsize(FONT_BODY)
    tbl.scale(1, 1.55)

    # Style header row
    for col_idx in range(n_cols):
        cell = tbl[0, col_idx]
        cell.set_facecolor(HEADER_BG)
        cell.set_text_props(color=HEADER_FG, fontweight="bold", fontsize=FONT_HEADER)
        cell.set_edgecolor(BORDER)

    # Style body cells — edges and font
    for row_idx in range(1, n_rows + 1):
        for col_idx in range(n_cols):
            cell = tbl[row_idx, col_idx]
            cell.set_edgecolor(BORDER)
            cell.set_linewidth(0.4)
            # Bold the Country column
            if col_idx == 0:
                cell.set_text_props(fontweight="bold")

    ax.set_title(title, fontsize=11, fontweight="bold", color=HEADER_BG,
                 pad=10, loc="left")

    fig.tight_layout(pad=0.4)
    fig.savefig(out_path, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"Saved figure: {out_path}")


def generate_backtest_summary() -> None:
    if not BACKTEST_SERIES_PATH.exists() or not BACKTEST_METRICS_PATH.exists():
        print("Backtest data missing. Skipping backtest summary.")
        return

    series = pd.read_csv(BACKTEST_SERIES_PATH)
    metrics = pd.read_csv(BACKTEST_METRICS_PATH).set_index("Country")

    summary = []
    for country in series["Country"].unique():
        df_c = series[series["Country"] == country].sort_values("Date")
        start_actual   = df_c["Actual_Log_HP"].iloc[0]
        end_actual     = df_c["Actual_Log_HP"].iloc[-1]
        end_forecast   = df_c["Forecast_Log_HP"].iloc[-1]
        actual_pct     = (np.exp(end_actual   - start_actual) - 1) * 100
        forecast_pct   = (np.exp(end_forecast - start_actual) - 1) * 100
        error_pct      = forecast_pct - actual_pct
        rmse = metrics.loc[country, "RMSE"] if country in metrics.index else np.nan
        mae  = metrics.loc[country, "MAE"]  if country in metrics.index else np.nan
        summary.append({
            "Country":            country,
            "Period":             f"{df_c['Date'].iloc[0]} – {df_c['Date'].iloc[-1]}",
            "Actual Growth %":    round(actual_pct,   1),
            "Forecast Growth %":  round(forecast_pct, 1),
            "Forecast Miss %":    round(error_pct,    1),
            "RMSE":               round(rmse, 4),
            "MAE":                round(mae,  4),
        })

    out_df = pd.DataFrame(summary)
    out_df.to_csv(BACKTEST_DIR / "table_backtest_absolute_summary.csv", index=False)

    save_table_figure(
        df=out_df,
        title="Backtest Accuracy — Actual vs. Forecasted Growth (Short-Horizon VECM, 2018–2020)",
        out_path=FIG_BACKTEST_DIR / "figure_table_backtest_summary.png",
        highlight_col="Forecast Miss %",
    )


def generate_future_summary() -> None:
    if not FUTURE_SERIES_PATH.exists() or not CLEAN_DATA_PATH.exists() or not PREF_PATH.exists():
        print("Future forecast or clean data missing. Skipping future summary.")
        return

    series = pd.read_csv(FUTURE_SERIES_PATH)
    clean  = pd.read_csv(CLEAN_DATA_PATH)
    pref   = pd.read_csv(PREF_PATH).set_index("Country")

    summary = []
    for country in series["Country"].unique():
        df_c    = series[series["Country"] == country].sort_values("Date")
        clean_c = clean[clean["Country"] == country].dropna(subset=["L_Property_Real"])
        if clean_c.empty or country not in pref.index:
            continue
        spec     = pref.loc[country, "Preferred_Spec"]
        prop_col = f"L_Property_{spec}"
        last_log = clean_c[prop_col].iloc[-1]
        end_log  = df_c["Forecast_Log_HP"].iloc[-1]
        lo_log   = df_c["Lower_90_CI"].iloc[-1]
        hi_log   = df_c["Upper_90_CI"].iloc[-1]
        summary.append({
            "Country":              country,
            "Spec":                 spec,
            "Latest Data":          clean_c["Date"].iloc[-1],
            "Forecast End":         df_c["Date"].iloc[-1],
            "Expected Growth %":    round((np.exp(end_log - last_log) - 1) * 100, 1),
            "Pessimistic (90 CI)%": round((np.exp(lo_log  - last_log) - 1) * 100, 1),
            "Optimistic (90 CI)%":  round((np.exp(hi_log  - last_log) - 1) * 100, 1),
        })

    out_df = pd.DataFrame(summary).sort_values("Expected Growth %", ascending=False).reset_index(drop=True)
    out_df.to_csv(FUTURE_DIR / "table_future_absolute_summary.csv", index=False)

    save_table_figure(
        df=out_df,
        title="Future House Price Projections to 2026 — ranked by expected growth (VECM, 90 % CI)",
        out_path=FIG_FUTURE_DIR / "figure_table_future_projections.png",
        highlight_col="Expected Growth %",
    )


def main() -> None:
    print("Generating summary table figures...")
    generate_backtest_summary()
    generate_future_summary()
    print("Done.")


if __name__ == "__main__":
    main()
