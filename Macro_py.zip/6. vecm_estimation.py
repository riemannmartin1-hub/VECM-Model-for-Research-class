from pathlib import Path

import numpy as np
import pandas as pd
from statsmodels.stats.diagnostic import acorr_lm
from statsmodels.tsa.vector_ar.vecm import VECM

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
MODEL_DIR = RESULTS_DIR / "vecm_summaries"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)
MODEL_DIR.mkdir(parents=True, exist_ok=True)

DATA_PATH = DATA_DIR / "clean_data.csv"
COINT_PATH = RESULTS_DIR / "coint_results.csv"
ADF_PATH = RESULTS_DIR / "adf_results.csv"
VECM_PATH = RESULTS_DIR / "vecm_results.csv"
DIAG_PATH = RESULTS_DIR / "vecm_diagnostics.csv"

ALL_ENDOG = ["L_GDP_per_capita", "Inflation", "L_Pop", "Yield_10Y"]
# Toleranz für die Stabilitätsprüfung: VECM-Modelle haben rechnerisch
# immer eine Wurzel auf dem Einheitskreis. Ganz minimale Überschreitungen
# sind also numerisches Rauschen und kein echtes Stabilitätsproblem.
STABILITY_TOL = 1e-6
# Verschärft von 1.05 auf 1.01: ein Eigenwert-Betrag von 1.04 erzeugt
# bei 10 Jahren Horizont eine 5x Verstärkung — das ist kein Rauschen.
WEAK_UPPER_BOUND = 1.01


def var_max_root(var_coefs: np.ndarray) -> float:
    # Stabilitätscheck: Das VECM wird in ein äquivalentes VAR umgeschrieben
    # und der größte Eigenwert berechnet. Liegt dieser im Einheitskreis,
    # ist das Modell stabil.
    p, k, _ = var_coefs.shape
    companion = np.zeros((k * p, k * p))
    companion[:k, :] = np.hstack(var_coefs)
    if p > 1:
        companion[k:, :-k] = np.eye(k * (p - 1))
    roots = np.linalg.eigvals(companion)
    return float(np.max(np.abs(roots)))


def lm_autocorr_pvalue(residuals: np.ndarray, nlags: int) -> float:
    # Test auf Autokorrelation in den Residuen. Wir nehmen pro Modell den
    # kleinsten p-Wert über alle Gleichungen - so bekommt der schlechteste
    # Fall das letzte Wort (konservative Bewertung).
    pvals = []
    for i in range(residuals.shape[1]):
        try:
            _, pval, _, _ = acorr_lm(residuals[:, i], nlags=nlags)
            pvals.append(float(pval))
        except Exception:
            continue
    if not pvals:
        return np.nan
    return float(np.min(pvals))


def get_i1_vars(adf: pd.DataFrame, country: str, prop_col: str) -> list[str]:
    """Filtert die endogenen Variablen auf I(1)-Kandidaten für ein Land.
    Die Häuserpreis-Variable wird immer eingeschlossen (sie ist die Zielvariable).
    Andere Variablen müssen in den ADF-Ergebnissen als I1_Candidate == True bestätigt sein."""
    country_adf = adf[adf["Country"] == country]
    i1_vars = [prop_col]  # Häuserpreis immer dabei
    for var in ALL_ENDOG:
        row = country_adf[country_adf["Variable"] == var]
        if not row.empty and bool(row.iloc[0]["I1_Candidate"]):
            i1_vars.append(var)
    return i1_vars


def main() -> None:
    df = pd.read_csv(DATA_PATH, parse_dates=["Date"]).sort_values(["Country", "Date"])
    coint = pd.read_csv(COINT_PATH)
    adf = pd.read_csv(ADF_PATH)
    # Nur Modelle schätzen, bei denen der Kointegrationstest grünes Licht gegeben hat.
    valid = coint[coint["Supports_VECM"] == True].copy()

    vecm_rows = []
    diag_rows = []

    for _, row in valid.iterrows():
        country = row["Country"]
        model_prop = row["Model"]
        # Lag und Rang aus dem vorherigen Schritt übernehmen.
        lag = int(row["Chosen_k_ar_diff"]) if not pd.isna(row["Chosen_k_ar_diff"]) else 1
        rank = int(row["Cointegrating_Ranks"]) if not pd.isna(row["Cointegrating_Ranks"]) else 1
        rank = max(rank, 1)

        # I(1)-Filterung: nur Variablen einschliessen, die per ADF als I(1) bestätigt sind.
        cols = get_i1_vars(adf, country, model_prop)
        if len(cols) < 2:
            print(f"Skipping {country} - {model_prop}: fewer than 2 I(1) variables")
            continue

        cdf = df[df["Country"] == country].set_index("Date")[cols].dropna()
        if cdf.shape[0] < 35:
            continue

        k = len(cols)  # Anzahl endogener Variablen (variiert pro Land)

        try:
            # VECM schätzen.
            model = VECM(cdf, k_ar_diff=lag, coint_rank=rank, deterministic="co")
            res = model.fit()

            # Beta = Langfrist-Beziehungen, Alpha = Anpassungsgeschwindigkeit
            # zurück zum Gleichgewicht.
            beta_df = pd.DataFrame(res.beta, columns=[f"CE_{i}" for i in range(rank)], index=cols)
            alpha_df = pd.DataFrame(res.alpha, columns=[f"CE_{i}_adj" for i in range(rank)], index=cols)

            # Modell-Qualität prüfen: Residuen ohne Autokorrelation und stabile Wurzeln.
            lm_p = lm_autocorr_pvalue(res.resid, nlags=max(2, lag + 1))
            max_root = var_max_root(res.var_rep)
            stable = max_root <= (1.0 + STABILITY_TOL)
            # Bonferroni-Korrektur: bei k Gleichungen ist die nominale Schwelle
            # 0.05/k, damit die familienweise Fehlerrate bei 5% bleibt.
            bonferroni_threshold = 0.05 / k
            no_autocorr = bool(lm_p > bonferroni_threshold) if not np.isnan(lm_p) else False

            # Modelle in drei Kategorien einsortieren - macht die spätere
            # Auswahl der "besten" Spezifikation pro Land einfach.
            if stable and no_autocorr:
                evaluation = "Solid"
            elif max_root <= WEAK_UPPER_BOUND:
                evaluation = "Weak"
            else:
                evaluation = "Not Suitable"

            vecm_row = {
                "Country": country,
                "Model_Prop": model_prop,
                "Lag_k_ar_diff": lag,
                "Rank": rank,
                "Endog_Vars": ";".join(cols),
            }
            for name in cols:
                vecm_row[f"Beta_CE0_{name}"] = beta_df.loc[name, "CE_0"]
                vecm_row[f"Alpha_CE0_{name}"] = alpha_df.loc[name, "CE_0_adj"]
            vecm_rows.append(vecm_row)

            diag_rows.append(
                {
                    "Country": country,
                    "Model_Prop": model_prop,
                    "N_Endog": k,
                    "Bonferroni_Threshold": bonferroni_threshold,
                    "LM_Autocorr_PValue": lm_p,
                    "No_Autocorrelation": no_autocorr,
                    "Max_AR_Root_Modulus": max_root,
                    "Is_Stable": stable,
                    "Evaluation": evaluation,
                }
            )

            # Vollständige Modell-Zusammenfassung als Textdatei sichern,
            # falls man später Details nachschauen will.
            summary_path = MODEL_DIR / f"{country}_{model_prop}_summary.txt"
            with open(summary_path, "w", encoding="utf-8") as f:
                f.write(res.summary().as_text())

        except Exception as err:
            print(f"Model failed {country} - {model_prop}: {err}")

    pd.DataFrame(vecm_rows).to_csv(VECM_PATH, index=False)
    pd.DataFrame(diag_rows).to_csv(DIAG_PATH, index=False)
    print(f"Saved VECM coefficients: {VECM_PATH}")
    print(f"Saved diagnostics: {DIAG_PATH}")


if __name__ == "__main__":
    main()
