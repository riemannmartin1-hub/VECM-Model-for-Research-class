from pathlib import Path

import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / "results"
PAPER_DIR = RESULTS_DIR / "paper_ready"
PAPER_DIR.mkdir(parents=True, exist_ok=True)


def write_country_preferred_spec(diag: pd.DataFrame, vecm: pd.DataFrame) -> None:
    """
    Wählt für jedes Land die bevorzugte VECM-Spezifikation.

    Methodische Regel (siehe §4.x im Paper): Reale Hauspreis-Spezifikation
    hat Vorrang vor der nominalen, unabhängig vom Diagnostik-Status. Begründung:
    Nominale Hauspreise enthalten konstruktionsbedingt das kumulierte log-CPI;
    in einem Kointegrationssystem mit der stationären Inflationsrate (aber ohne
    log-CPI als eigene Variable) müsste dieser Drift von den übrigen β-Koeffizienten
    absorbiert werden — eine Fehlspezifikation. Dass die Diagnostik in der nominalen
    Variante häufig besser aussieht, ist kein ökonomisches Argument, sondern
    spiegelt die trendstärkere Datenlage wider.

    Fallback auf Nominal nur, wenn die reale Spezifikation für ein Land gar nicht
    VECM-fähig war (Kointegrationstest fehlgeschlagen oder Schätzung gescheitert).
    Solche Fälle landen in fallback_to_nominal.csv und sind in §6.6 als Limitation
    zu erwähnen.

    "Not Suitable"-Modelle (max root > 1.01) werden komplett ausgeschlossen.

    Diagnostik-Status (Solid/Weak) wird weiterhin als Spalte mitgegeben, damit
    Lesende schwächere reale Modelle erkennen können.
    """
    merged = vecm.merge(diag, on=["Country", "Model_Prop"], how="left")

    preferred_rows = []
    fallback_rows = []
    for country in sorted(merged["Country"].unique()):
        cdf = merged[merged["Country"] == country].copy()
        if cdf.empty:
            continue
        # "Not Suitable"-Modelle komplett ausschliessen.
        cdf = cdf[cdf["Evaluation"] != "Not Suitable"]
        if cdf.empty:
            continue
        # Erste Wahl: reale Spezifikation, unabhängig von Solid/Weak
        real_pick = cdf[cdf["Model_Prop"] == "L_Property_Real"]
        if not real_pick.empty:
            preferred_rows.append(real_pick.iloc[0])
            continue
        # Fallback: nominale Spezifikation, mit Dokumentation
        nominal_pick = cdf[cdf["Model_Prop"] == "L_Property_Nominal"]
        if not nominal_pick.empty:
            preferred_rows.append(nominal_pick.iloc[0])
            fallback_rows.append({
                "Country": country,
                "Reason": "Reale Spezifikation nicht VECM-fähig; nominal als Fallback verwendet.",
            })

    # Fallback-Liste persistieren, damit sie im Paper transparent referenziert werden kann.
    if fallback_rows:
        pd.DataFrame(fallback_rows).to_csv(
            PAPER_DIR / "fallback_to_nominal.csv", index=False
        )
        print(f"WARNUNG: {len(fallback_rows)} Land/Länder fallen zurück auf nominale Spezifikation:")
        for r in fallback_rows:
            print(f"  - {r['Country']}")
    else:
        # Eventuell vorhandene alte Fallback-Datei entfernen, damit der Output konsistent bleibt.
        old = PAPER_DIR / "fallback_to_nominal.csv"
        if old.exists():
            old.unlink()

    preferred = pd.DataFrame(preferred_rows)
    if preferred.empty:
        return

    # Auf die für das Paper relevanten Spalten reduzieren und mit lesbaren
    # Bezeichnungen versehen (Nominal/Real statt der internen Spaltennamen).
    # Da nicht alle Länder dieselben Beta-Spalten haben (I(1)-Filterung),
    # nehmen wir nur die vorhandenen Spalten.
    base_cols = ["Country", "Model_Prop", "Evaluation", "LM_Autocorr_PValue", "Max_AR_Root_Modulus"]
    available_beta = [c for c in ["Beta_CE0_L_GDP_per_capita", "Beta_CE0_Inflation", "Beta_CE0_L_Pop", "Beta_CE0_Yield_10Y"] if c in preferred.columns]

    preferred_table = preferred[base_cols + available_beta].copy()
    preferred_table["Preferred_Spec"] = preferred_table["Model_Prop"].map(
        {"L_Property_Nominal": "Nominal", "L_Property_Real": "Real"}
    )
    out_cols = ["Country", "Preferred_Spec", "Evaluation", "LM_Autocorr_PValue", "Max_AR_Root_Modulus"] + available_beta
    preferred_table = preferred_table[out_cols]
    preferred_table.to_csv(PAPER_DIR / "table_country_preferred_spec.csv", index=False)


def write_appendix_nominal_robustness(diag: pd.DataFrame, vecm: pd.DataFrame) -> None:
    """
    Anhang B: Nominal-Spezifikation als Robustheitsvergleich.

    Pro Land wird dieselbe Tabellenstruktur wie für die reale Hauptspezifikation
    erzeugt — diesmal jedoch immer auf der nominalen Schätzung. Wenn keine nominale
    Schätzung verfügbar ist, wird das Land übersprungen (gehört dann ebenfalls in
    die Limitations).
    """
    merged = vecm.merge(diag, on=["Country", "Model_Prop"], how="left")
    nominal_only = merged[merged["Model_Prop"] == "L_Property_Nominal"].copy()
    if nominal_only.empty:
        return
    nominal_only["Spec"] = "Nominal"
    base_cols = ["Country", "Spec", "Evaluation", "LM_Autocorr_PValue", "Max_AR_Root_Modulus"]
    available_beta = [c for c in ["Beta_CE0_L_GDP_per_capita", "Beta_CE0_Inflation", "Beta_CE0_L_Pop", "Beta_CE0_Yield_10Y"] if c in nominal_only.columns]
    nominal_only[base_cols + available_beta].sort_values("Country").to_csv(
        PAPER_DIR / "appendix_B_nominal_robustness.csv", index=False
    )


def main() -> None:
    # Alle Zwischenergebnisse aus den vorherigen Schritten einlesen.
    cov = pd.read_csv(RESULTS_DIR / "country_coverage_overview.csv")
    adf = pd.read_csv(RESULTS_DIR / "adf_results.csv")
    coint = pd.read_csv(RESULTS_DIR / "coint_results.csv")
    lag = pd.read_csv(RESULTS_DIR / "lag_selection.csv")
    vecm = pd.read_csv(RESULTS_DIR / "vecm_results.csv")
    diag = pd.read_csv(RESULTS_DIR / "vecm_diagnostics.csv")

    # Robustheitscheck ist optional - nicht jeder Durchlauf erzeugt diese Datei.
    robust_path = RESULTS_DIR / "robustness_checks.csv"
    robust = pd.read_csv(robust_path) if robust_path.exists() else pd.DataFrame()

    # Jede Tabelle einzeln als CSV speichern (mit "table_"-Präfix, damit
    # man im Ordner sofort sieht, was zu welcher Paper-Tabelle gehört).
    cov.to_csv(PAPER_DIR / "table_country_coverage.csv", index=False)
    adf.to_csv(PAPER_DIR / "table_adf_results.csv", index=False)
    coint.to_csv(PAPER_DIR / "table_cointegration_results.csv", index=False)
    lag.to_csv(PAPER_DIR / "table_lag_selection.csv", index=False)
    vecm.to_csv(PAPER_DIR / "table_vecm_coefficients.csv", index=False)
    diag.to_csv(PAPER_DIR / "table_vecm_diagnostics.csv", index=False)
    if not robust.empty:
        robust.to_csv(PAPER_DIR / "table_robustness_checks.csv", index=False)

    # Zusätzlich alles in eine Excel-Datei mit benannten Tabs - praktisch
    # für Co-Autoren oder Reviewer, die nicht 7 CSVs einzeln öffnen wollen.
    with pd.ExcelWriter(PAPER_DIR / "Macro_House_Prices_Results.xlsx") as writer:
        cov.to_excel(writer, sheet_name="Country_Coverage", index=False)
        adf.to_excel(writer, sheet_name="ADF_Results", index=False)
        coint.to_excel(writer, sheet_name="Cointegration", index=False)
        lag.to_excel(writer, sheet_name="Lag_Selection", index=False)
        vecm.to_excel(writer, sheet_name="VECM_Coefficients", index=False)
        diag.to_excel(writer, sheet_name="Diagnostics", index=False)
        if not robust.empty:
            robust.to_excel(writer, sheet_name="Robustness", index=False)

    write_country_preferred_spec(diag=diag, vecm=vecm)
    write_appendix_nominal_robustness(diag=diag, vecm=vecm)
    print(f"Paper-ready outputs saved to: {PAPER_DIR}")


if __name__ == "__main__":
    main()
