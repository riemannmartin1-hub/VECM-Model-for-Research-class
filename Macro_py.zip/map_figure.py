from pathlib import Path
import warnings

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import TwoSlopeNorm, Normalize
from matplotlib.cm import ScalarMappable
import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
RESULTS_DIR = PROJECT_ROOT / "results"
FIG_DIR = RESULTS_DIR / "figures" / "paper_ready"
FIG_DIR.mkdir(parents=True, exist_ok=True)

PREF_PATH = RESULTS_DIR / "paper_ready" / "table_country_preferred_spec.csv"
VECM_PATH = RESULTS_DIR / "vecm_results.csv"

ISO3_MAP = {
    "AT": "AUT", "BE": "BEL", "DE": "DEU", "DK": "DNK",
    "ES": "ESP", "FI": "FIN", "FR": "FRA", "GB": "GBR",
    "GR": "GRC", "IT": "ITA", "NL": "NLD", "SE": "SWE",
    "PT": "PRT", "NO": "NOR", "CH": "CHE", "HU": "HUN",
}
ISO2_MAP = {v: k for k, v in ISO3_MAP.items()}

# (result_column, panel_title, matplotlib_colormap, use_diverging_norm)
PANELS = [
    ("Alpha_HP",                  "Adjustment speed (α)",        "RdYlGn",  True),
    ("Beta_CE0_L_GDP_per_capita", "GDP elasticity (β_GDP)",       "YlOrBr",  False),
    ("Beta_CE0_Yield_10Y",        "Yield sensitivity (β_Yield)",  "RdBu_r",  True),
]

XLIM = (-12, 35)
YLIM = (34, 72)


def load_results() -> pd.DataFrame:
    pref = pd.read_csv(PREF_PATH)
    vecm = pd.read_csv(VECM_PATH)

    pref["Model_Prop"] = pref["Preferred_Spec"].map(
        {"Real": "L_Property_Real", "Nominal": "L_Property_Nominal"}
    )

    def get_alpha(country: str, model_prop: str) -> float:
        col = f"Alpha_CE0_{model_prop}"
        row = vecm[(vecm["Country"] == country) & (vecm["Model_Prop"] == model_prop)]
        if row.empty or col not in row.columns:
            return np.nan
        return float(row.iloc[0][col])

    pref["Alpha_HP"] = [get_alpha(r["Country"], r["Model_Prop"]) for _, r in pref.iterrows()]
    pref["ISO3"] = pref["Country"].map(ISO3_MAP)
    return pref


def load_world():
    try:
        import geopandas as gpd
    except ImportError:
        raise ImportError("geopandas is required: pip install geopandas")

    with warnings.catch_warnings():
        warnings.simplefilter("ignore")

        # Versuch 1: alter geopandas Weg
        try:
            return gpd.read_file(gpd.datasets.get_path("naturalearth_lowres"))
        except Exception:
            pass

        # Versuch 2: direkt von Natural Earth herunterladen
        try:
            import geopandas as gpd
            url = "https://naturalearth.s3.amazonaws.com/110m_cultural/ne_110m_admin_0_countries.zip"
            world = gpd.read_file(url)
            if "ISO_A3" in world.columns and "iso_a3" not in world.columns:
                world = world.rename(columns={"ISO_A3": "iso_a3"})
            return world
        except Exception:
            pass

        # Versuch 3: alternativer Mirror
        try:
            url = "https://github.com/nvkelso/natural-earth-vector/raw/master/geojson/ne_110m_admin_0_countries.geojson"
            world = gpd.read_file(url)
            cols = [c.lower() for c in world.columns]
            world.columns = [c.lower() for c in world.columns]
            if "iso_a3" not in world.columns:
                for c in world.columns:
                    if "iso" in c and "a3" in c:
                        world = world.rename(columns={c: "iso_a3"})
                        break
            return world
        except Exception:
            pass

    raise RuntimeError(
        "Konnte Weltkartendata nicht laden. Bitte prüfe deine Internetverbindung."
    )


def draw_panel(
    ax: plt.Axes,
    world,
    data: pd.DataFrame,
    col: str,
    label: str,
    cmap_name: str,
    diverging: bool,
) -> None:
    europe = world.cx[XLIM[0]:XLIM[1], YLIM[0]:YLIM[1]].copy()

    merged = europe.merge(
        data[["ISO3", col]],
        left_on="iso_a3",
        right_on="ISO3",
        how="left",
    )

    valid = merged[col].dropna().values.astype(float)
    if len(valid) == 0:
        ax.set_axis_off()
        ax.set_title(f"{label}\n(no data)", fontsize=10)
        return

    vmin, vmax = float(valid.min()), float(valid.max())
    if diverging and vmin < 0 < vmax:
        norm = TwoSlopeNorm(vcenter=0, vmin=vmin, vmax=vmax)
    else:
        norm = Normalize(vmin=vmin, vmax=vmax)

    no_data = merged[merged[col].isna()]
    if not no_data.empty:
        no_data.plot(ax=ax, color="#d9d9d9", linewidth=0.3, edgecolor="#aaaaaa")

    has_data = merged[merged[col].notna()].copy()
    if not has_data.empty:
        has_data.plot(
            ax=ax,
            column=col,
            cmap=cmap_name,
            norm=norm,
            linewidth=0.5,
            edgecolor="white",
            legend=False,
        )

    # 2-letter country labels at representative points
    for _, row in has_data.iterrows():
        iso2 = ISO2_MAP.get(str(row.get("iso_a3", "")), "")
        if not iso2:
            continue
        pt = row.geometry.representative_point()
        if not (XLIM[0] <= pt.x <= XLIM[1] and YLIM[0] <= pt.y <= YLIM[1]):
            continue
        ax.text(
            pt.x, pt.y, iso2,
            fontsize=6, ha="center", va="center",
            color="black", fontweight="bold",
            bbox=dict(boxstyle="round,pad=0.1", fc="white", alpha=0.45, ec="none"),
        )

    sm = ScalarMappable(cmap=cmap_name, norm=norm)
    sm.set_array([])
    cb = plt.colorbar(sm, ax=ax, orientation="horizontal", pad=0.02, fraction=0.04, aspect=35)
    cb.ax.tick_params(labelsize=7)

    ax.set_xlim(*XLIM)
    ax.set_ylim(*YLIM)
    ax.set_axis_off()
    ax.set_title(label, fontsize=10, pad=8)


def main() -> None:
    data = load_results()
    world = load_world()

    fig, axes = plt.subplots(1, 3, figsize=(15, 6), facecolor="white")

    for ax, (col, label, cmap, diverging) in zip(axes, PANELS):
        draw_panel(ax, world, data, col, label, cmap, diverging)

    fig.suptitle(
        "VECM Results across Europe — preferred specification per country",
        fontsize=12,
        y=1.02,
    )
    fig.tight_layout()

    out = FIG_DIR / "europe_map.png"
    fig.savefig(out, dpi=200, bbox_inches="tight", facecolor="white")
    plt.close(fig)
    print(f"Saved Europe map: {out}")


if __name__ == "__main__":
    main()