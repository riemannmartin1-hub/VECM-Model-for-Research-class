from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from statsmodels.tsa.vector_ar.vecm import VECM

# "Agg"-Backend setzen, bevor pyplot Figuren erzeugt - sonst Probleme auf Servern ohne Display.
matplotlib.use("Agg")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
PAPER_DIR = RESULTS_DIR / "paper_ready"
FIG_DIR = RESULTS_DIR / "figures" / "paper_ready"
FIG_DIR.mkdir(parents=True, exist_ok=True)
PAPER_DIR.mkdir(parents=True, exist_ok=True)

DATA_PATH = DATA_DIR / "clean_data.csv"
COINT_PATH = RESULTS_DIR / "coint_results.csv"
PREF_PATH = PAPER_DIR / "table_country_preferred_spec.csv"

ALL_ENDOG = ["L_GDP_per_capita", "Inflation", "L_Pop", "Yield_10Y"]

# Beschriftungen und Farben für die Treiber im Beitragsplot.
DRIVER_LABELS = {
    "Own_lag": "House price (own lag)",
    "L_GDP_per_capita": "GDP per capita",
    "Inflation": "Inflation",
    "L_Pop": "Population",
    "Yield_10Y": "10Y yield",
    "LongRun": "Long-run adjustment & const.",
    "Residual": "Residual",
}

DRIVER_COLORS = {
    "Own_lag": "#8fa6bf",
    "L_GDP_per_capita": "#4472c4",
    "Inflation": "#ed7d31",
    "L_Pop": "#70ad47",
    "Yield_10Y": "#ffc000",
    "LongRun": "#7030a0",
    "Residual": "#a5a5a5",
}


def fit_preferred(df: pd.DataFrame, coint: pd.DataFrame, country: str, prop_col: str):
    crow = coint[(coint["Country"] == country) & (coint["Model"] == prop_col)]
    if crow.empty or not bool(crow.iloc[0]["Supports_VECM"]):
        return None
    lag = int(crow.iloc[0]["Chosen_k_ar_diff"])
    rank = max(int(crow.iloc[0]["Cointegrating_Ranks"]), 1)

    # Endogene Variablen aus Kointegrationstest übernehmen (I(1)-gefiltert).
    if "Endog_Vars" in crow.columns and pd.notna(crow.iloc[0]["Endog_Vars"]):
        cols = str(crow.iloc[0]["Endog_Vars"]).split(";")
    else:
        cols = [prop_col] + ALL_ENDOG

    endog_drivers = [c for c in cols if c != prop_col]

    data = (
        df[df["Country"] == country]
        .set_index("Date")[cols]
        .dropna()
        .sort_index()
    )
    if data.shape[0] < 35:
        return None

    try:
        res = VECM(data, k_ar_diff=lag, coint_rank=rank, deterministic="co").fit()
    except Exception:
        return None

    return {"res": res, "data": data, "lag": lag, "rank": rank, "prop_col": prop_col,
            "cols": cols, "endog_drivers": endog_drivers}


def compute_actual_vs_fitted(fit: dict):
    res = fit["res"]
    data = fit["data"]
    prop_col = fit["prop_col"]

    resid_hp = np.asarray(res.resid)[:, 0]
    nobs = resid_hp.shape[0]

    actual_level = data[prop_col]
    dy_hp = actual_level.diff().dropna()
    dy_hp_fit = dy_hp.iloc[-nobs:]
    fitted_dy = dy_hp_fit.values - resid_hp
    fitted_index = dy_hp_fit.index

    # VERSION 1: 1-Step-Ahead Forecast (for Model Fit check)
    prior_level = actual_level.shift(1).loc[fitted_index]
    fitted_1step = pd.Series(prior_level.values + fitted_dy, index=fitted_index)
    
    # VERSION 2: Pure-Beta Structural Equilibrium (for Fundamental Value check)
    beta = np.asarray(res.beta)[:, 0]  # first cointegrating vector
    u = data.values @ beta
    u = u - u.mean()
    u_series = pd.Series(u, index=data.index)
    fitted_equil = actual_level - u_series

    actual_diff = pd.Series(dy_hp_fit.values, index=fitted_index)
    fitted_diff = pd.Series(fitted_dy, index=fitted_index)
    return actual_level, fitted_1step, fitted_equil, actual_diff, fitted_diff


def compute_contributions(fit: dict):
    res = fit["res"]
    data = fit["data"]
    prop_col = fit["prop_col"]
    lag = fit["lag"]
    endog_drivers = fit["endog_drivers"]

    cols = fit["cols"]
    k = len(cols)
    y = data[cols].values
    dy = np.diff(y, axis=0)

    gamma_hp = np.asarray(res.gamma)[0, :].reshape(lag, k)
    resid_hp = np.asarray(res.resid)[:, 0]
    nobs = resid_hp.shape[0]

    start = len(y) - nobs
    quarters = data.index[start:]

    rows = []
    for idx, t in enumerate(range(start, len(y))):
        own_lag = 0.0
        drivers = {col: 0.0 for col in endog_drivers}
        for i in range(1, lag + 1):
            d = dy[t - 1 - i]
            own_lag += gamma_hp[i - 1, 0] * d[0]
            for j, col in enumerate(endog_drivers, start=1):
                drivers[col] += gamma_hp[i - 1, j] * d[j]

        actual_dhp = float(y[t, 0] - y[t - 1, 0])
        residual = float(resid_hp[idx])
        fitted_dhp = actual_dhp - residual
        long_run = fitted_dhp - own_lag - sum(drivers.values())

        row = {
            "Date": quarters[idx],
            "Own_lag": own_lag,
            **drivers,
            "LongRun": long_run,
            "Residual": residual,
            "Actual": actual_dhp,
        }
        rows.append(row)

    q_contrib = pd.DataFrame(rows).set_index("Date")
    annual = q_contrib.resample("YE").sum(min_count=4)
    annual = annual.dropna(how="any")
    return annual


def compute_misalignment(fit: dict) -> pd.Series:
    """
    Berechnet die kointegrierende Abweichung u_t = β'X_t aus dem ERSTEN
    Kointegrationsvektor (CE_0).

    Mit der statsmodels-Normalisierung gilt β[0,0] = 1, d.h. der Koeffizient
    auf den (log) Hauspreis in CE_0 ist eins. Damit hat u_t die natürliche
    Interpretation:
        u_t > 0  →  log Hauspreis liegt über dem makroökonomischen
                    Langfristgleichgewicht (überbewertet)
        u_t < 0  →  unter dem Gleichgewicht (unterbewertet)

    Die Reihe wird über das Schätz-Sample entmittelt. Mit deterministic="co"
    sitzt die Konstante in der Kurzfristdynamik, sodass β'X_t theoretisch
    erwartungswert-null im Langfristgleichgewicht ist - im endlichen Sample
    aber nicht exakt null wird. Die Entmittelung legt die Null-Linie im
    Plot auf den landesinternen Sample-Durchschnitt der Abweichung.

    Bei rank > 1 wird ausschließlich CE_0 verwendet, konsistent mit dem
    sonstigen β-Reporting im Projekt (vecm_results.csv speichert nur
    Beta_CE0_*). Zusätzliche Kointegrationsvektoren werden auf der
    Misalignment-Ebene ignoriert; in der Summary-Tabelle wird Rank als
    Spalte mitgegeben, damit hohe-Rang-Länder erkennbar bleiben.
    """
    res = fit["res"]
    data = fit["data"]
    
    # Pure-Beta Structural Equilibrium (for Misalignment)
    # This uses the first cointegrating vector (CE0) from the full-rank model.
    beta = np.asarray(res.beta)[:, 0]  # erster Kointegrationsvektor
    u = data.values @ beta              # shape (T,)
    u = u - u.mean()                    # Entmittelung pro Land
    return pd.Series(u, index=data.index, name="u_t")


def plot_actual_vs_fitted(panels: dict, suffix: str = "1step") -> None:
    countries = sorted(panels.keys())
    if not countries:
        return
    ncols = 4
    nrows = int(np.ceil(len(countries) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(ncols * 3.2, nrows * 2.3))
    axes = np.atleast_1d(axes).reshape(-1)
    for ax in axes:
        ax.set_visible(False)
    for i, c in enumerate(countries):
        ax = axes[i]
        ax.set_visible(True)
        actual, fitted = panels[c]
        ax.plot(actual.index, actual.values, color="#1f4e79", linewidth=1.1, label="Actual")
        
        lbl = "Fitted (1-step)" if suffix == "1step" else "LR Equilibrium (Pure Beta)"
        ax.plot(fitted.index, fitted.values, color="#c0504d", linewidth=1.0, linestyle="--", label=lbl)
        
        ax.set_title(c, fontsize=10)
        ax.tick_params(axis="x", labelrotation=45, labelsize=7)
        ax.tick_params(axis="y", labelsize=7)
        ax.grid(True, linewidth=0.3, alpha=0.4)
        
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, fontsize=9, frameon=False, bbox_to_anchor=(0.5, -0.02))
    
    title = "Actual vs Fitted House Prices (1-Step Ahead)" if suffix == "1step" else "Actual vs Long-Run Equilibrium (Pure Betas)"
    fig.suptitle(title, fontsize=12, y=1.01)
    
    fig.tight_layout()
    filename = f"actual_vs_fitted_{suffix}.png"
    fig.savefig(FIG_DIR / filename, bbox_inches="tight", dpi=160)
    plt.close(fig)


def plot_actual_vs_fitted_diff(panels: dict) -> None:
    countries = sorted(panels.keys())
    if not countries:
        return
    ncols = 4
    nrows = int(np.ceil(len(countries) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(ncols * 3.2, nrows * 2.3))
    axes = np.atleast_1d(axes).reshape(-1)
    for ax in axes:
        ax.set_visible(False)
    for i, c in enumerate(countries):
        ax = axes[i]
        ax.set_visible(True)
        actual_d, fitted_d = panels[c]
        ax.plot(actual_d.index, actual_d.values, color="#1f4e79", linewidth=1.0,
                label="Actual Δ log HP")
        ax.plot(fitted_d.index, fitted_d.values, color="#c0504d", linewidth=1.0,
                linestyle="--", label="Fitted Δ log HP")
        ax.axhline(0, color="black", linewidth=0.4)
        ax.set_title(c, fontsize=10)
        ax.tick_params(axis="x", labelrotation=45, labelsize=7)
        ax.tick_params(axis="y", labelsize=7)
        ax.grid(True, linewidth=0.3, alpha=0.4)
    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, fontsize=9,
               frameon=False, bbox_to_anchor=(0.5, -0.02))
    fig.suptitle("Actual vs fitted quarterly change in log house prices (preferred specification)",
                 fontsize=12, y=1.01)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "actual_vs_fitted_diff.png", bbox_inches="tight", dpi=160)
    plt.close(fig)


def plot_contributions(panels: dict, fits: dict) -> None:
    countries = sorted(panels.keys())
    if not countries:
        return
    ncols = 4
    nrows = int(np.ceil(len(countries) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(ncols * 3.4, nrows * 2.5))
    axes = np.atleast_1d(axes).reshape(-1)
    for ax in axes:
        ax.set_visible(False)

    # Alle Treiber-Spalten sammeln, die in mindestens einem Land vorkommen.
    all_driver_names = set()
    for c in countries:
        ctr = panels[c]
        for col in ctr.columns:
            if col not in ("Actual", "Residual", "LongRun", "Own_lag"):
                all_driver_names.add(col)
    all_driver_names = sorted(all_driver_names)

    # Reihenfolge: Own_lag zuerst, dann alphabetisch die anderen Treiber.
    all_drivers = ["Own_lag"] + [d for d in ALL_ENDOG if d in all_driver_names]

    first_plotted = True
    for i, c in enumerate(countries):
        ax = axes[i]
        ax.set_visible(True)
        ctr = panels[c]
        if ctr.empty:
            ax.set_title(f"{c} (no data)", fontsize=9)
            continue
        years = ctr.index.year
        x = np.arange(len(years))

        # Nur die Treiber verwenden, die für dieses Land existieren.
        drivers = [d for d in all_drivers if d in ctr.columns]
        driver_vals = ctr[drivers].values
        actual_vals = ctr["Actual"].values
        sum_drivers = driver_vals.sum(axis=1)
        other_vals = actual_vals - sum_drivers

        pos = np.clip(driver_vals, 0, None)
        neg = np.clip(driver_vals, None, 0)
        bottom_pos = np.zeros(len(years))
        bottom_neg = np.zeros(len(years))
        for j, name in enumerate(drivers):
            lbl = DRIVER_LABELS.get(name, name)
            clr = DRIVER_COLORS.get(name, "#888888")
            ax.bar(x, pos[:, j], bottom=bottom_pos, width=0.85,
                   color=clr, linewidth=0,
                   label=lbl if first_plotted else None)
            bottom_pos = bottom_pos + pos[:, j]
            ax.bar(x, neg[:, j], bottom=bottom_neg, width=0.85,
                   color=clr, linewidth=0)
            bottom_neg = bottom_neg + neg[:, j]

        other_pos = np.clip(other_vals, 0, None)
        other_neg = np.clip(other_vals, None, 0)
        ax.bar(x, other_pos, bottom=bottom_pos, width=0.85,
               color="#a5a5a5", linewidth=0, alpha=0.85,
               label="Long-run adj. + residual" if first_plotted else None)
        ax.bar(x, other_neg, bottom=bottom_neg, width=0.85,
               color="#a5a5a5", linewidth=0, alpha=0.85)

        ax.plot(x, actual_vals, color="black", linewidth=1.1,
                marker="o", markersize=2.4,
                label="Actual Δ log HP (annual)" if first_plotted else None)
        ax.axhline(0, color="black", linewidth=0.4)

        first_plotted = False

        tick_idx = np.linspace(0, len(years) - 1, min(5, len(years))).astype(int)
        ax.set_xticks(tick_idx)
        ax.set_xticklabels([str(years[k]) for k in tick_idx], fontsize=7, rotation=0)
        ax.tick_params(axis="y", labelsize=7)
        ax.set_title(c, fontsize=10)
        ax.grid(True, axis="y", linewidth=0.3, alpha=0.4)

        ymax = max(np.abs(actual_vals).max(), np.abs(sum_drivers).max(), np.abs(other_vals).max())
        ax.set_ylim(-1.15 * ymax, 1.15 * ymax)

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=4, fontsize=8,
               frameon=False, bbox_to_anchor=(0.5, -0.04))
    fig.suptitle("Contributions to annual change in log house prices (VECM short-run, preferred specification)",
                 fontsize=12, y=1.01)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "contribution_decomposition.png", bbox_inches="tight", dpi=160)
    plt.close(fig)


def plot_misalignment(panels: dict) -> None:
    """
    16-Panel-Plot von u_t pro Land. Positive Bereiche (rot) = Hauspreis
    über makroökonomischem Gleichgewicht; negative Bereiche (blau) = darunter.
    Werte sind in log-Punkten: 0.10 ≈ 10% Abweichung.
    """
    countries = sorted(panels.keys())
    if not countries:
        return
    ncols = 4
    nrows = int(np.ceil(len(countries) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(ncols * 3.4, nrows * 2.5))
    axes = np.atleast_1d(axes).reshape(-1)
    for ax in axes:
        ax.set_visible(False)

    for i, c in enumerate(countries):
        ax = axes[i]
        ax.set_visible(True)
        u = panels[c]
        if u.empty:
            ax.set_title(f"{c} (no data)", fontsize=9)
            continue

        # Rot = überbewertet (u > 0), Blau = unterbewertet (u < 0).
        # fill_between mit interpolate=True schliesst die Flächen sauber an der Null-Linie.
        ax.fill_between(u.index, u.values, 0, where=(u.values >= 0),
                        color="#c0504d", alpha=0.45, interpolate=True,
                        label="overvalued (u_t > 0)" if i == 0 else None)
        ax.fill_between(u.index, u.values, 0, where=(u.values < 0),
                        color="#4472c4", alpha=0.45, interpolate=True,
                        label="undervalued (u_t < 0)" if i == 0 else None)
        ax.plot(u.index, u.values, color="black", linewidth=0.8)
        ax.axhline(0, color="black", linewidth=0.5)

        ax.set_title(c, fontsize=10)
        ax.tick_params(axis="x", labelrotation=45, labelsize=7)
        ax.tick_params(axis="y", labelsize=7)
        ax.grid(True, linewidth=0.3, alpha=0.4)

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=2, fontsize=9,
               frameon=False, bbox_to_anchor=(0.5, -0.02))
    fig.suptitle("Misalignment u_t = β'X_t — deviation from long-run macroeconomic equilibrium "
                 "(log-points, demeaned per country)",
                 fontsize=12, y=1.01)
    fig.tight_layout()
    fig.savefig(FIG_DIR / "misalignment.png", bbox_inches="tight", dpi=160)
    plt.close(fig)


def write_misalignment_outputs(panels: dict, fits: dict, pref: pd.DataFrame) -> None:
    """
    Schreibt zwei CSVs in PAPER_DIR:

    - misalignment_series.csv (long format): Country, Date, u_t für jedes Quartal.
      Diese Datei ist die Grundlage für die spätere Backtest-Erweiterung
      (Quintilsortierung in der to-do).

    - table_misalignment_summary.csv: pro Land das letzte Quartal, das aktuelle
      u_t, die Standardabweichung über das Sample, sowie Min/Max für Kontext
      und Rank zur Transparenz für hohe-Rang-Länder.
    """
    long_frames = []
    summary_rows = []

    for country in sorted(panels.keys()):
        u = panels[country]
        if u.empty:
            continue

        # Long-format Reihe
        frame = u.rename("u_t").reset_index()
        frame["Country"] = country
        long_frames.append(frame[["Country", "Date", "u_t"]])

        # Summary
        spec_row = pref.loc[pref["Country"] == country, "Preferred_Spec"]
        spec = spec_row.iloc[0] if not spec_row.empty else ""
        rank = int(fits[country]["rank"]) if country in fits else np.nan

        summary_rows.append({
            "Country": country,
            "Preferred_Spec": spec,
            "Rank": rank,
            "Latest_Date": u.index[-1].strftime("%Y-%m-%d"),
            "Latest_u": float(u.iloc[-1]),
            "Std_u": float(u.std(ddof=0)),
            "Min_u": float(u.min()),
            "Max_u": float(u.max()),
            "N_Obs": int(u.shape[0]),
        })

    if long_frames:
        pd.concat(long_frames, ignore_index=True).to_csv(
            PAPER_DIR / "misalignment_series.csv", index=False
        )
    if summary_rows:
        pd.DataFrame(summary_rows).sort_values("Country").to_csv(
            PAPER_DIR / "table_misalignment_summary.csv", index=False
        )


def main() -> None:
    df = pd.read_csv(DATA_PATH, parse_dates=["Date"])
    coint = pd.read_csv(COINT_PATH)
    pref = pd.read_csv(PREF_PATH)

    fitted_1step_panels = {}
    fitted_equil_panels = {}
    fitted_diff_panels = {}
    contrib_panels = {}
    misalignment_panels = {}
    fits = {}

    for _, prow in pref.iterrows():
        country = prow["Country"]
        spec = prow["Preferred_Spec"]
        prop_col = f"L_Property_{spec}"
        fit = fit_preferred(df, coint, country, prop_col)
        if fit is None:
            continue
        fits[country] = fit

        actual, f_1s, f_eq, actual_d, fitted_d = compute_actual_vs_fitted(fit)
        fitted_1step_panels[country] = (actual, f_1s)
        fitted_equil_panels[country] = (actual, f_eq)
        fitted_diff_panels[country] = (actual_d, fitted_d)

        contrib = compute_contributions(fit)
        if not contrib.empty:
            contrib_panels[country] = contrib

        misalignment_panels[country] = compute_misalignment(fit)

    plot_actual_vs_fitted(fitted_1step_panels, suffix="1step")
    plot_actual_vs_fitted(fitted_equil_panels, suffix="equilibrium")
    plot_actual_vs_fitted_diff(fitted_diff_panels)
    plot_contributions(contrib_panels, fits)
    plot_misalignment(misalignment_panels)
    write_misalignment_outputs(misalignment_panels, fits, pref)
    print(f"Client figures saved to: {FIG_DIR}")


if __name__ == "__main__":
    main()
