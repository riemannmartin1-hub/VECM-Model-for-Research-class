from pathlib import Path

import numpy as np
import pandas as pd
from statsmodels.tsa.stattools import adfuller

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

INPUT_PATH = DATA_DIR / "clean_data.csv"
OUTPUT_PATH = RESULTS_DIR / "adf_results.csv"

# Pro Variable die passende Test-Spezifikation:
# "ct" = Konstante + Trend (für Variablen mit klarem Trend wie Preise oder BIP),
# "c"  = nur Konstante (für trendlose Variablen wie Inflation oder Zinsen).
# Die richtige Wahl ist wichtig, sonst verliert der Test an Aussagekraft.
ADF_VARS = {
    "L_Property_Real": "ct",
    "L_Property_Nominal": "ct",
    "L_GDP_per_capita": "ct",
    "L_Pop": "ct",
    "Inflation": "c",
    "Yield_10Y": "c",
}


def run_adf(series: pd.Series, regression: str) -> tuple[float, float]:
    # Wrapper um den ADF-Test mit Schutzmechanismen:
    # - zu kurze Reihen (< 10 Jahre) werden übersprungen
    # - bei numerischen Problemen wird NaN zurückgegeben statt zu crashen
    s = series.dropna()
    if s.shape[0] < 40:
        import warnings
        warnings.warn(
            f"ADF test skipped: only {s.shape[0]} observations "
            f"(minimum 40 required for reliable '{regression}' specification)"
        )
        return np.nan, np.nan
    try:
        stat, pval, *_ = adfuller(s, autolag="AIC", regression=regression)
        return float(stat), float(pval)
    except Exception:
        return np.nan, np.nan


def main() -> None:
    df = pd.read_csv(INPUT_PATH, parse_dates=["Date"]).sort_values(["Country", "Date"])
    rows = []

    # Für jedes Land und jede Variable wird zweimal getestet:
    # einmal auf das Niveau, einmal auf die 1. Differenz.
    # Eine Variable gilt als I(1)-Kandidat (für VECM geeignet), wenn sie
    # im Niveau NICHT stationär ist, in der Differenz aber schon.
    for country, cdf in df.groupby("Country"):
        cdf = cdf.set_index("Date")
        for var, reg in ADF_VARS.items():
            if var not in cdf.columns:
                continue
            lev_stat, lev_p = run_adf(cdf[var], regression=reg)
            diff_stat, diff_p = run_adf(cdf[var].diff(), regression="c")
            rows.append(
                {
                    "Country": country,
                    "Variable": var,
                    "ADF_Stat_Level": lev_stat,
                    "P_value_Level": lev_p,
                    "ADF_Stat_Diff": diff_stat,
                    "P_value_Diff": diff_p,
                    "I1_Candidate": bool((lev_p > 0.05) and (diff_p <= 0.05))
                    if not np.isnan(lev_p) and not np.isnan(diff_p)
                    else False,
                }
            )

    pd.DataFrame(rows).to_csv(OUTPUT_PATH, index=False)
    print(f"Saved ADF results: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()
