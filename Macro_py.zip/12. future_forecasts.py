from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from statsmodels.tsa.vector_ar.vecm import VECM

matplotlib.use("Agg")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
PAPER_DIR = RESULTS_DIR / "paper_ready" / "future_forecasts"
FIG_DIR = RESULTS_DIR / "figures" / "paper_ready" / "future_forecasts"

PAPER_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

DATA_PATH = DATA_DIR / "clean_data.csv"
COINT_PATH = RESULTS_DIR / "coint_results.csv"
PREF_PATH = RESULTS_DIR / "paper_ready" / "table_country_preferred_spec.csv"

# Target year to forecast up to
TARGET_YEAR = 2026


def main() -> None:
    df = pd.read_csv(DATA_PATH, parse_dates=["Date"])
    coint = pd.read_csv(COINT_PATH)
    
    if not PREF_PATH.exists():
        print("Preferred specifications not found. Run prepare_output.py first.")
        return
        
    pref = pd.read_csv(PREF_PATH)

    forecast_frames = []
    forecast_panels = {}

    for _, prow in pref.iterrows():
        country = prow["Country"]
        spec = prow["Preferred_Spec"]
        prop_col = f"L_Property_{spec}"

        crow = coint[(coint["Country"] == country) & (coint["Model"] == prop_col)]
        if crow.empty:
            continue
            
        crow = crow.iloc[0]
        lag = int(crow["Chosen_k_ar_diff"])
        rank = max(int(crow["Cointegrating_Ranks"]), 1)

        if "Endog_Vars" in crow.index and pd.notna(crow["Endog_Vars"]):
            cols = str(crow["Endog_Vars"]).split(";")
        else:
            cols = [prop_col, "L_GDP_per_capita", "Inflation", "Yield_10Y"]

        data = df[df["Country"] == country].set_index("Date")[cols].dropna().sort_index()
        
        # Train on FULL available dataset
        train = data
        
        if len(train) < 40:
            print(f"Skipping {country} - insufficient data.")
            continue

        try:
            model = VECM(train, k_ar_diff=lag, coint_rank=rank, deterministic="co")
            res = model.fit()
            
            # Calculate how many quarters we need to reach the end of TARGET_YEAR
            last_date = train.index[-1]
            years_diff = TARGET_YEAR - last_date.year
            quarters_diff = 4 - last_date.quarter
            steps = (years_diff * 4) + quarters_diff
            
            if steps <= 0:
                print(f"Skipping {country} - data already reaches {TARGET_YEAR}.")
                continue
                
            # Forecast dynamic steps
            forecast, lower, upper = res.predict(steps=steps, alpha=0.10) # 90% confidence interval
            
            # Create future dates
            future_dates = pd.date_range(start=last_date + pd.DateOffset(months=3), periods=steps, freq="QS")
            
            # Extract house price forecast
            forecast_hp = forecast[:, 0]
            lower_hp = lower[:, 0]
            upper_hp = upper[:, 0]
            
            # Save trajectory
            f_df = pd.DataFrame({
                "Date": future_dates,
                "Country": country,
                "Forecast_Log_HP": forecast_hp,
                "Lower_90_CI": lower_hp,
                "Upper_90_CI": upper_hp
            })
            forecast_frames.append(f_df)
            
            # Save for plotting
            forecast_panels[country] = {
                "train_dates": train.index,
                "train_hp": train[prop_col].values,
                "future_dates": future_dates,
                "forecast_hp": forecast_hp,
                "lower_hp": lower_hp,
                "upper_hp": upper_hp
            }
            
        except Exception as e:
            print(f"Forecast failed for {country}: {e}")

    # Export CSVs
    if forecast_frames:
        pd.concat(forecast_frames, ignore_index=True).to_csv(
            PAPER_DIR / "future_forecast_series.csv", index=False
        )
        print(f"Saved forecast series: {PAPER_DIR / 'future_forecast_series.csv'}")

    # Generate 16-panel plot
    countries = sorted(forecast_panels.keys())
    if not countries:
        return
        
    ncols = 4
    nrows = int(np.ceil(len(countries) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(ncols * 3.4, nrows * 2.5))
    axes = np.atleast_1d(axes).reshape(-1)
    
    for ax in axes:
        ax.set_visible(False)
        
    for i, c in enumerate(countries):
        ax = axes[i]
        ax.set_visible(True)
        p = forecast_panels[c]
        
        # Plot last 10 years of training data for context
        ax.plot(p["train_dates"][-40:], p["train_hp"][-40:], color="#1f4e79", linewidth=1.5, label="Historical Actuals" if i==0 else None)
        
        # Plot forecast line
        # Connect the last actual point to the first forecast point so there's no gap
        conn_dates = [p["train_dates"][-1], p["future_dates"][0]]
        conn_vals = [p["train_hp"][-1], p["forecast_hp"][0]]
        ax.plot(conn_dates, conn_vals, color="#c0504d", linewidth=1.5, linestyle="--")
        
        ax.plot(p["future_dates"], p["forecast_hp"], color="#c0504d", linewidth=1.5, linestyle="--", label="VECM Forecast (to 2026)" if i==0 else None)
        
        # Plot confidence interval
        ax.fill_between(p["future_dates"], p["lower_hp"], p["upper_hp"], color="#c0504d", alpha=0.15, label="90% Confidence Interval" if i==0 else None)
        
        # Vertical line at "Today" (end of historical data)
        ax.axvline(p["train_dates"][-1], color="gray", linestyle=":", linewidth=1.0)
        
        ax.set_title(c, fontsize=10)
        ax.tick_params(axis="x", labelrotation=45, labelsize=7)
        ax.tick_params(axis="y", labelsize=7)
        ax.grid(True, linewidth=0.3, alpha=0.4)

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, fontsize=9, frameon=False, bbox_to_anchor=(0.5, -0.02))
    fig.suptitle(f"Future House Price Projections (End of {TARGET_YEAR})", fontsize=12, y=1.02)
    fig.tight_layout()
    
    out_path = FIG_DIR / "future_forecasts.png"
    fig.savefig(out_path, bbox_inches="tight", dpi=160)
    plt.close(fig)
    print(f"Saved forecast plots: {out_path}")


if __name__ == "__main__":
    main()
