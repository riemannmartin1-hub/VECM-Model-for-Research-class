from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from statsmodels.tsa.vector_ar.vecm import VECM

matplotlib.use("Agg")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
PAPER_DIR = RESULTS_DIR / "paper_ready" / "backtest_results"
FIG_DIR = RESULTS_DIR / "figures" / "paper_ready" / "backtest_results"

PAPER_DIR.mkdir(parents=True, exist_ok=True)
FIG_DIR.mkdir(parents=True, exist_ok=True)

DATA_PATH = DATA_DIR / "clean_data.csv"
COINT_PATH = RESULTS_DIR / "coint_results.csv"
PREF_PATH = RESULTS_DIR / "paper_ready" / "table_country_preferred_spec.csv"

# Wir schneiden die Daten Ende 2017 ab und testen einen 
# kurzen Vorhersagehorizont (12 Quartale = 3 Jahre).
# VECM-Modelle sind für kurze Horizonte aussagekräftig; 
# bei mehr als 16 Quartalen kehren sie nur noch flach zum Mittelwert zurück.
CUTOFF_DATE = pd.Timestamp("2017-12-31")
MAX_FORECAST_STEPS = 12  # Maximal 12 Quartale vorhersagen


def main() -> None:
    df = pd.read_csv(DATA_PATH, parse_dates=["Date"])
    coint = pd.read_csv(COINT_PATH)
    
    if not PREF_PATH.exists():
        print("Preferred specifications not found. Run prepare_output.py first.")
        return
        
    pref = pd.read_csv(PREF_PATH)

    forecast_frames = []
    metrics_rows = []
    forecast_panels = {}

    for _, prow in pref.iterrows():
        country = prow["Country"]
        spec = prow["Preferred_Spec"]
        prop_col = f"L_Property_{spec}"

        crow = coint[(coint["Country"] == country) & (coint["Model"] == prop_col)]
        if crow.empty:
            continue
            
        crow = crow.iloc[0]
        lag = int(crow["Chosen_k_ar_diff"])
        rank = max(int(crow["Cointegrating_Ranks"]), 1)

        if "Endog_Vars" in crow.index and pd.notna(crow["Endog_Vars"]):
            cols = str(crow["Endog_Vars"]).split(";")
        else:
            cols = [prop_col, "L_GDP_per_capita", "Inflation", "Yield_10Y"]

        data = df[df["Country"] == country].set_index("Date")[cols].dropna().sort_index()
        
        # Split into training and testing
        train = data[:CUTOFF_DATE]
        test = data[CUTOFF_DATE + pd.Timedelta(days=1):]
        
        # Auf kurzen Horizont beschränken
        test = test.iloc[:MAX_FORECAST_STEPS]
        
        if len(train) < 40 or len(test) < 4:
            continue

        try:
            model = VECM(train, k_ar_diff=lag, coint_rank=rank, deterministic="co")
            res = model.fit()
            
            steps = len(test)
            forecast, lower, upper = res.predict(steps=steps, alpha=0.05)
            
            actual_hp = test[prop_col].values
            forecast_hp = forecast[:, 0]
            
            rmse = float(np.sqrt(np.mean((actual_hp - forecast_hp) ** 2)))
            mae = float(np.mean(np.abs(actual_hp - forecast_hp)))
            
            metrics_rows.append({
                "Country": country,
                "Preferred_Spec": spec,
                "Train_End": train.index[-1].strftime("%Y-%m-%d"),
                "Test_Start": test.index[0].strftime("%Y-%m-%d"),
                "Test_End": test.index[-1].strftime("%Y-%m-%d"),
                "Forecast_Steps": steps,
                "RMSE": rmse,
                "MAE": mae
            })
            
            f_df = pd.DataFrame({
                "Date": test.index,
                "Country": country,
                "Actual_Log_HP": actual_hp,
                "Forecast_Log_HP": forecast_hp
            })
            forecast_frames.append(f_df)
            
            forecast_panels[country] = {
                "train_dates": train.index,
                "train_hp": train[prop_col].values,
                "test_dates": test.index,
                "actual_hp": actual_hp,
                "forecast_hp": forecast_hp
            }
            
        except Exception as e:
            print(f"Forecast failed for {country}: {e}")

    if forecast_frames:
        pd.concat(forecast_frames, ignore_index=True).to_csv(
            PAPER_DIR / "backtest_forecast_series.csv", index=False
        )
    if metrics_rows:
        pd.DataFrame(metrics_rows).to_csv(
            PAPER_DIR / "table_backtest_metrics.csv", index=False
        )
        print(f"Saved short-horizon backtest metrics: {PAPER_DIR / 'table_backtest_metrics.csv'}")

    countries = sorted(forecast_panels.keys())
    if not countries:
        return
        
    ncols = 4
    nrows = int(np.ceil(len(countries) / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(ncols * 3.4, nrows * 2.5))
    axes = np.atleast_1d(axes).reshape(-1)
    
    for ax in axes:
        ax.set_visible(False)
        
    for i, c in enumerate(countries):
        ax = axes[i]
        ax.set_visible(True)
        p = forecast_panels[c]
        
        # Zeige die letzten 5 Jahre (20 Quartale) des Trainings zum visuellen Vergleich
        ax.plot(p["train_dates"][-20:], p["train_hp"][-20:], color="#1f4e79", linewidth=1.2, label="Historical Actuals" if i==0 else None)
        
        ax.plot(p["test_dates"], p["actual_hp"], color="black", linewidth=1.2, label="Out-of-Sample Actuals" if i==0 else None)
        ax.plot(p["test_dates"], p["forecast_hp"], color="#c0504d", linewidth=1.2, linestyle="--", label="VECM Short-Horizon Forecast" if i==0 else None)
        
        ax.axvline(CUTOFF_DATE, color="gray", linestyle=":", linewidth=1.0)
        
        ax.set_title(c, fontsize=10)
        ax.tick_params(axis="x", labelrotation=45, labelsize=7)
        ax.tick_params(axis="y", labelsize=7)
        ax.grid(True, linewidth=0.3, alpha=0.4)

    handles, labels = axes[0].get_legend_handles_labels()
    fig.legend(handles, labels, loc="lower center", ncol=3, fontsize=9, frameon=False, bbox_to_anchor=(0.5, -0.02))
    fig.suptitle(f"Short-Horizon VECM Forecast Accuracy (Max {MAX_FORECAST_STEPS} Quarters, starting {CUTOFF_DATE.year+1})", fontsize=12, y=1.02)
    fig.tight_layout()
    
    out_path = FIG_DIR / "backtest_forecasts.png"
    fig.savefig(out_path, bbox_inches="tight", dpi=160)
    plt.close(fig)
    print(f"Saved forecast plots: {out_path}")


if __name__ == "__main__":
    main()
