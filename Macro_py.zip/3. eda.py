from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns
from scipy.stats import median_abs_deviation

# "Agg"-Backend muss vor pyplot gesetzt werden, sonst stürzt das Skript
# auf Servern ohne Bildschirm ab.
matplotlib.use("Agg")

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
FIG_DIR = RESULTS_DIR / "figures" / "eda"
FIG_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

INPUT_PATH = DATA_DIR / "clean_data.csv"

PLOT_VARS = ["Property_Real", "Property_Nominal", "GDP_per_capita", "Inflation", "Pop", "Yield_10Y"]


def main() -> None:
    df = pd.read_csv(INPUT_PATH, parse_dates=["Date"]).sort_values(["Country", "Date"])

    # Beschreibende Statistiken pro Land speichern (Min, Max, Mittelwert,
    # Quantile). Dient als schneller Überblick über die Daten.
    desc = df.groupby("Country")[PLOT_VARS].describe(percentiles=[0.05, 0.5, 0.95])
    desc.to_csv(RESULTS_DIR / "descriptive_stats.csv")

    # Auffällige Werte (mehr als 3 Standardabweichungen vom Mittelwert)
    # markieren und in einer Datei sammeln. Wichtig: Werte werden NICHT
    # automatisch korrigiert - ökonomische Schocks sollen drinbleiben.
    outlier_rows = []
    for country, cdf in df.groupby("Country"):
        for var in PLOT_VARS:
            s = cdf[var]
            if s.notna().sum() < 10:
                continue
            med = s.median()
            mad = median_abs_deviation(s.dropna(), scale="normal")
            z = (s - med) / mad if mad > 0 else pd.Series(0.0, index=s.index)
            flagged = cdf.loc[z.abs() > 3, ["Date", var]].copy()
            if not flagged.empty:
                flagged["Country"] = country
                flagged["Variable"] = var
                flagged = flagged.rename(columns={var: "Value"})
                outlier_rows.append(flagged)
    if outlier_rows:
        pd.concat(outlier_rows, ignore_index=True).to_csv(RESULTS_DIR / "eda_outlier_flags.csv", index=False)

    # Pro Variable einen Plot mit 16 Mini-Diagrammen (eines pro Land) erzeugen,
    # damit man auf einen Blick die Zeitverläufe vergleichen kann.
    sns.set(style="whitegrid")
    countries = sorted(df["Country"].unique())
    for var in PLOT_VARS:
        plt.figure(figsize=(15, 10))
        for i, country in enumerate(countries, start=1):
            ax = plt.subplot(4, 4, i)
            cdf = df[df["Country"] == country].set_index("Date")
            if cdf[var].notna().any():
                cdf[var].plot(ax=ax, linewidth=1.2, title=country)
            ax.tick_params(axis="x", labelrotation=45)
        plt.suptitle(f"{var} by Country", y=1.02, fontsize=15)
        plt.tight_layout()
        plt.savefig(FIG_DIR / f"ts_{var}.png", bbox_inches="tight", dpi=180)
        plt.close()

    print("EDA outputs saved.")


if __name__ == "__main__":
    main()
