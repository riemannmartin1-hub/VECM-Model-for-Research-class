from pathlib import Path

import numpy as np
import pandas as pd

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
DATA_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

RAW_PATH = DATA_DIR / "raw_data.csv"
CLEAN_PATH = DATA_DIR / "clean_data.csv"
COVERAGE_PATH = RESULTS_DIR / "country_coverage_overview.csv"

CORE_VARS = ["Property_Real", "Property_Nominal", "GDP_per_capita", "Inflation", "Pop", "Yield_10Y"]


def availability_row(group: pd.DataFrame, country: str) -> dict:
    # Sammelt pro Land: Start, Ende, Anzahl gültiger Werte und Anteil
    # fehlender Werte je Variable. Dient als Daten-Übersicht für das Paper.
    row = {"Country": country}
    for var in CORE_VARS:
        valid = group.loc[group[var].notna(), "Date"]
        row[f"{var}_Start"] = valid.min().strftime("%Y-%m-%d") if not valid.empty else np.nan
        row[f"{var}_End"] = valid.max().strftime("%Y-%m-%d") if not valid.empty else np.nan
        row[f"{var}_Count"] = int(valid.shape[0]) if not valid.empty else 0
        row[f"{var}_MissingShare"] = float(group[var].isna().mean())
    row["Rows_Total"] = int(group.shape[0])
    return row


def main() -> None:
    if not RAW_PATH.exists():
        raise FileNotFoundError(f"Missing raw input: {RAW_PATH}")

    # Daten einlesen, sortieren, Duplikate entfernen und auf den Zeitraum
    # ab 1990 beschränken (davor zu viele Lücken in den BIS-Häuserpreisen).
    df = pd.read_csv(RAW_PATH, parse_dates=["Date"])
    df = df.sort_values(["Country", "Date"]).drop_duplicates(subset=["Country", "Date"], keep="last")
    df = df[df["Date"] >= pd.Timestamp("1990-01-01")].copy()

    for col in CORE_VARS + ["Real_GDP"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # Logarithmen für Niveau-Variablen anlegen, weil das VECM-Modell auf
    # log-Niveaus arbeitet. Werte <= 0 vorher auf NaN setzen, sonst gibt log() Fehler.
    for raw_col, log_col in [
        ("Property_Real", "L_Property_Real"),
        ("Property_Nominal", "L_Property_Nominal"),
        ("GDP_per_capita", "L_GDP_per_capita"),
        ("Pop", "L_Pop"),
    ]:
        df[raw_col] = np.where(df[raw_col] <= 0, np.nan, df[raw_col])
        df[log_col] = np.log(df[raw_col])

    # Wichtig: BIP- und Zinslücken werden NICHT aufgefüllt. Eine Imputation
    # würde die späteren Stationaritäts- und Kointegrationstests verzerren.
    clean_cols = [
        "Country",
        "Date",
        "Property_Real",
        "Property_Nominal",
        "GDP_per_capita",
        "Inflation",
        "Pop",
        "Yield_10Y",
        "L_Property_Real",
        "L_Property_Nominal",
        "L_GDP_per_capita",
        "L_Pop",
    ]
    clean = df[clean_cols].copy()
    clean.to_csv(CLEAN_PATH, index=False)

    # Coverage-Übersicht über alle Länder erzeugen und speichern.
    coverage = []
    for country, group in clean.groupby("Country"):
        coverage.append(availability_row(group, country))
    pd.DataFrame(coverage).sort_values("Country").to_csv(COVERAGE_PATH, index=False)

    print(f"Saved cleaned data: {CLEAN_PATH}")
    print(f"Saved coverage report: {COVERAGE_PATH}")


if __name__ == "__main__":
    main()
