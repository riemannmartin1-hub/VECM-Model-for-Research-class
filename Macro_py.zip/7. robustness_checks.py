from pathlib import Path

import numpy as np
import pandas as pd
from statsmodels.tsa.vector_ar.vecm import VECM

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

DATA_PATH = DATA_DIR / "clean_data.csv"
COINT_PATH = RESULTS_DIR / "coint_results.csv"
DIAG_PATH = RESULTS_DIR / "vecm_diagnostics.csv"
OUTPUT_PATH = RESULTS_DIR / "robustness_checks.csv"


def main() -> None:
    df = pd.read_csv(DATA_PATH, parse_dates=["Date"])
    coint = pd.read_csv(COINT_PATH)
    diag = pd.read_csv(DIAG_PATH)

    # Robustheitscheck nur für die als "Solid" eingestuften Modelle -
    # bei schwachen Modellen wäre dieser zusätzliche Test nicht aussagekräftig.
    solid = diag[diag["Evaluation"] == "Solid"][["Country", "Model_Prop"]]
    if solid.empty:
        print("No solid models available for robustness checks.")
        return

    # Krisen-Dummies für Finanzkrise und Corona-Pandemie. Idee: Wenn die
    # Hauptergebnisse nach Kontrolle dieser Schocks stabil bleiben, sind
    # sie nicht nur durch die Krisen getrieben.
    df["Crisis_2008_2009"] = ((df["Date"] >= "2008-01-01") & (df["Date"] <= "2009-12-31")).astype(int)
    df["Crisis_2020_2021"] = ((df["Date"] >= "2020-01-01") & (df["Date"] <= "2021-12-31")).astype(int)

    rows = []
    for _, model_row in solid.iterrows():
        country = model_row["Country"]
        model_prop = model_row["Model_Prop"]

        # Gleiche Lag- und Rang-Wahl wie im Hauptmodell verwenden -
        # nur die Krisen-Dummies kommen als zusätzliche Variablen hinzu.
        coint_row = coint[(coint["Country"] == country) & (coint["Model"] == model_prop)]
        if coint_row.empty:
            continue
        coint_row = coint_row.iloc[0]
        lag = int(coint_row["Chosen_k_ar_diff"]) if not pd.isna(coint_row["Chosen_k_ar_diff"]) else 1
        rank = int(coint_row["Cointegrating_Ranks"]) if not pd.isna(coint_row["Cointegrating_Ranks"]) else 1
        rank = max(rank, 1)

        # Endogene Variablen aus dem Kointegrationstest übernehmen (I(1)-gefiltert).
        if "Endog_Vars" in coint_row.index and pd.notna(coint_row["Endog_Vars"]):
            cols = str(coint_row["Endog_Vars"]).split(";")
        else:
            cols = [model_prop, "L_GDP_per_capita", "Inflation", "L_Pop", "Yield_10Y"]

        exog_cols = ["Crisis_2008_2009", "Crisis_2020_2021"]
        cdf = df[df["Country"] == country].set_index("Date")
        model_data = cdf[cols + exog_cols].dropna()
        if model_data.shape[0] < 35:
            continue

        try:
            model = VECM(
                model_data[cols],
                exog=model_data[exog_cols],
                k_ar_diff=lag,
                coint_rank=rank,
                deterministic="co",
            )
            res = model.fit()
            # Wir speichern nur die Anpassungsgeschwindigkeit (Alpha) der
            # Häuserpreis-Gleichung. Diese Kennzahl zeigt, wie schnell sich
            # Preise ans langfristige Gleichgewicht zurückbewegen.
            alpha_main = float(res.alpha[0, 0]) if res.alpha.size > 0 else np.nan
            rows.append(
                {
                    "Country": country,
                    "Model_Prop": model_prop,
                    "Lag_k_ar_diff": lag,
                    "Rank": rank,
                    "Main_Alpha_with_Crisis_Dummies": alpha_main,
                    "Status": "Estimated",
                }
            )
        except Exception as err:
            # Fehler nicht verschlucken, sondern als eigene Zeile mit Status
            # ausgeben - dann sieht man auch im Output, was schiefgelaufen ist.
            rows.append(
                {
                    "Country": country,
                    "Model_Prop": model_prop,
                    "Lag_k_ar_diff": lag,
                    "Rank": rank,
                    "Main_Alpha_with_Crisis_Dummies": np.nan,
                    "Status": f"Failed: {err}",
                }
            )

    pd.DataFrame(rows).to_csv(OUTPUT_PATH, index=False)
    print(f"Saved robustness checks: {OUTPUT_PATH}")


if __name__ == "__main__":
    main()

