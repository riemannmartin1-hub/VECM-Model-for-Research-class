from datetime import datetime
from pathlib import Path

import numpy as np
import pandas as pd
import pandas_datareader.data as web
import pandas_datareader.wb as wb

# Zeitraum und Ordnerstruktur für das Projekt.
START = datetime(1990, 1, 1)
END = datetime(2026, 1, 1)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
DATA_DIR.mkdir(parents=True, exist_ok=True)
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

# Pro Land die nötigen Datenbank-Codes ablegen: ISO-Kürzel für die Weltbank
# und FRED-Codes für BIP und Zinsen. Das Mapping ist hardcoded, weil jede
# Datenbank ihre eigene Code-Logik hat und sich das nicht automatisch ableiten lässt.
COUNTRIES = {
    "AT": {"iso3": "AUT", "gdp": "CLVMNACSCAB1GQAT", "yield_m": "IRLTLT01ATM156N"},
    "BE": {"iso3": "BEL", "gdp": "CLVMNACSCAB1GQBE", "yield_m": "IRLTLT01BEM156N"},
    "DE": {"iso3": "DEU", "gdp": "CLVMNACSCAB1GQDE", "yield_m": "IRLTLT01DEM156N"},
    "DK": {"iso3": "DNK", "gdp": "CLVMNACSCAB1GQDK", "yield_m": "IRLTLT01DKM156N"},
    "ES": {"iso3": "ESP", "gdp": "CLVMNACSCAB1GQES", "yield_m": "IRLTLT01ESM156N"},
    "FI": {"iso3": "FIN", "gdp": "CLVMNACSCAB1GQFI", "yield_m": "IRLTLT01FIM156N"},
    "FR": {"iso3": "FRA", "gdp": "CLVMNACSCAB1GQFR", "yield_m": "IRLTLT01FRM156N"},
    "GB": {"iso3": "GBR", "gdp": "NGDPRSAXDCGBQ", "yield_m": "IRLTLT01GBM156N"},
    "GR": {"iso3": "GRC", "gdp": "CLVMNACSCAB1GQEL", "yield_m": "IRLTLT01GRM156N"},
    "IT": {"iso3": "ITA", "gdp": "CLVMNACSCAB1GQIT", "yield_m": "IRLTLT01ITM156N"},
    "NL": {"iso3": "NLD", "gdp": "CLVMNACSCAB1GQNL", "yield_m": "IRLTLT01NLM156N"},
    "SE": {"iso3": "SWE", "gdp": "CLVMNACSCAB1GQSE", "yield_m": "IRLTLT01SEM156N"},
    "PT": {"iso3": "PRT", "gdp": "CLVMNACSCAB1GQPT", "yield_m": "IRLTLT01PTM156N"},
    "NO": {"iso3": "NOR", "gdp": "CLVMNACSCAB1GQNO", "yield_m": "IRLTLT01NOM156N"},
    "CH": {"iso3": "CHE", "gdp": "CLVMNACSAB1GQCH", "yield_m": "IRLTLT01CHM156N"},
    "HU": {"iso3": "HUN", "gdp": "CLVMNACSCAB1GQHU", "yield_m": "IRLTLT01HUM156N"},
}


def fetch_fred(series_code: str, col_name: str) -> pd.DataFrame:
    series = web.DataReader(series_code, "fred", START, END)
    series.columns = [col_name]
    return series


def quarterly_average(series: pd.DataFrame) -> pd.DataFrame:
    # Für monatliche Daten (z.B. Zinsen, CPI): Mittelwert pro Quartal bilden.
    return series.resample("QS").mean()


def quarterly_as_is(series: pd.DataFrame) -> pd.DataFrame:
    # Für bereits quartalsweise vorliegende Daten: nur auf einheitlichen Index bringen.
    return series.resample("QS").asfreq()


def fetch_population_quarterly(iso3: str) -> pd.DataFrame:
    # Bevölkerung gibt es bei der Weltbank nur jährlich.
    # Wir interpolieren geometrisch (linear in Logs), weil Bevölkerung
    # exponentiell wächst. Der Unterschied zu linearer Interpolation ist
    # minimal (~0.004% pro Quartal), aber methodisch sauberer.
    annual = wb.download(indicator="SP.POP.TOTL", country=iso3, start=1990, end=2025).reset_index()
    annual["year"] = pd.to_numeric(annual["year"])
    annual["Date"] = pd.to_datetime(annual["year"].astype(str) + "-01-01")
    annual = annual.set_index("Date").sort_index()[["SP.POP.TOTL"]]
    annual.columns = ["Pop"]
    # Geometrische Interpolation: in Logs interpolieren, dann zurücktransformieren.
    annual["LogPop"] = np.log(annual["Pop"])
    quarterly = annual[["LogPop"]].resample("QS").asfreq()
    quarterly["LogPop"] = quarterly["LogPop"].interpolate(method="linear")
    quarterly["Pop"] = np.exp(quarterly["LogPop"])
    quarterly = quarterly.drop(columns=["LogPop"])
    return quarterly


def fetch_country_data(country: str, meta: dict) -> pd.DataFrame:
    # Holt alle benötigten Variablen für ein einzelnes Land und führt sie
    # in einer Tabelle zusammen.
    iso3 = meta["iso3"]
    frame = pd.DataFrame()

    real_code = f"Q{country}R628BIS"
    nominal_code = f"Q{country}N628BIS"

    hp_real = quarterly_as_is(fetch_fred(real_code, "Property_Real"))
    hp_nom = quarterly_as_is(fetch_fred(nominal_code, "Property_Nominal"))
    gdp = quarterly_as_is(fetch_fred(meta["gdp"], "Real_GDP"))

    try:
        yld = quarterly_average(fetch_fred(meta["yield_m"], "Yield_10Y"))
    except Exception:
        # Notfall-Quelle für Griechenland, falls die monatliche Serie Lücken hat.
        yld = quarterly_as_is(fetch_fred("IRLTLT01GRQ156N", "Yield_10Y"))

    # Inflation als Prozent-Änderung des CPI gegenüber dem Vorjahresquartal.
    cpi = quarterly_average(fetch_fred(f"{iso3}CPIALLMINMEI", "CPI"))
    cpi["Inflation"] = cpi["CPI"].pct_change(4) * 100

    pop = fetch_population_quarterly(iso3)

    # Outer-Join: jede Variable behält ihren maximalen Zeitraum;
    # fehlende Quartale werden später in fix_data.py behandelt.
    for piece in [hp_real, hp_nom, gdp, yld, cpi[["Inflation"]], pop]:
        frame = piece if frame.empty else frame.join(piece, how="outer")

    frame["GDP_per_capita"] = frame["Real_GDP"] / frame["Pop"]
    frame["Country"] = country
    frame = frame.reset_index().rename(columns={"index": "Date"})
    return frame


def main() -> None:
    # Schleife über alle Länder. Falls ein Land scheitert (z.B. API-Fehler),
    # wird es übersprungen statt das ganze Skript abzubrechen.
    all_frames = []
    for ctry, meta in COUNTRIES.items():
        print(f"Fetching {ctry}...")
        try:
            all_frames.append(fetch_country_data(ctry, meta))
        except Exception as err:
            print(f"  Failed for {ctry}: {err}")

    if not all_frames:
        raise RuntimeError("No country data was fetched.")

    # Alle Länder in eine einzige Tabelle zusammenführen und als Rohdatei speichern.
    data = pd.concat(all_frames, ignore_index=True)
    data = data.sort_values(["Country", "Date"])
    data.to_csv(DATA_DIR / "raw_data.csv", index=False)
    print(f"Saved raw data: {DATA_DIR / 'raw_data.csv'}")
    print(f"Shape: {data.shape}")


if __name__ == "__main__":
    main()
