from pathlib import Path

import numpy as np
import pandas as pd
from statsmodels.tsa.vector_ar.vecm import select_coint_rank, select_order

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = PROJECT_ROOT / "data"
RESULTS_DIR = PROJECT_ROOT / "results"
RESULTS_DIR.mkdir(parents=True, exist_ok=True)

INPUT_PATH = DATA_DIR / "clean_data.csv"
ADF_PATH = RESULTS_DIR / "adf_results.csv"
COINT_PATH = RESULTS_DIR / "coint_results.csv"
LAG_PATH = RESULTS_DIR / "lag_selection.csv"

# Wir testen jedes Land mit zwei Varianten des Häuserpreises (real und nominal),
# um zu sehen, ob die Ergebnisse von der Wahl abhängen.
PROPERTY_SPECS = ["L_Property_Real", "L_Property_Nominal"]
ALL_ENDOG = ["L_GDP_per_capita", "Inflation", "L_Pop", "Yield_10Y"]


def safe_int(value, fallback: int = 2) -> int:
    # Falls die Lag-Auswahl keinen sinnvollen Wert liefert, nehmen wir
    # einen Standardwert (2 Lags), damit das Skript weiterlaufen kann.
    try:
        if value is None:
            return fallback
        return int(value)
    except Exception:
        return fallback


def get_i1_vars(adf: pd.DataFrame, country: str, prop_col: str) -> list[str]:
    """Filtert die endogenen Variablen auf I(1)-Kandidaten für ein Land.
    Die Häuserpreis-Variable wird immer eingeschlossen (Zielvariable).
    Andere Variablen müssen per ADF als I1_Candidate == True bestätigt sein.
    So wird verhindert, dass I(0)-Variablen in den Johansen-Test eingehen
    und den geschätzten Kointegrationsrang verfälschen."""
    country_adf = adf[adf["Country"] == country]
    i1_vars = [prop_col]  # Häuserpreis immer dabei
    for var in ALL_ENDOG:
        row = country_adf[country_adf["Variable"] == var]
        if not row.empty and bool(row.iloc[0]["I1_Candidate"]):
            i1_vars.append(var)
    return i1_vars


def main() -> None:
    df = pd.read_csv(INPUT_PATH, parse_dates=["Date"]).sort_values(["Country", "Date"])

    # ADF-Ergebnisse laden, um nur I(1)-Variablen in den Johansen-Test zu nehmen.
    if not ADF_PATH.exists():
        raise FileNotFoundError(
            f"ADF results not found at {ADF_PATH}. "
            "Run stationarity.py first."
        )
    adf = pd.read_csv(ADF_PATH)

    coint_rows = []
    lag_rows = []

    # Pro Land und pro Spezifikation den Kointegrationstest durchführen.
    for country, cdf in df.groupby("Country"):
        cdf = cdf.set_index("Date")
        for prop in PROPERTY_SPECS:
            # I(1)-Filterung: nur Variablen verwenden, die per ADF als I(1) bestätigt sind.
            cols = get_i1_vars(adf, country, prop)

            if len(cols) < 2:
                print(f"Skipping {country} - {prop}: fewer than 2 I(1) variables")
                coint_rows.append(
                    {
                        "Country": country,
                        "Model": prop,
                        "Endog_Vars": ";".join(cols),
                        "Sample_Start": np.nan,
                        "Sample_End": np.nan,
                        "N_Obs": 0,
                        "Chosen_Lag_VAR": np.nan,
                        "Chosen_k_ar_diff": np.nan,
                        "Cointegrating_Ranks": 0,
                        "Supports_VECM": False,
                    }
                )
                continue

            if not all(col in cdf.columns for col in cols):
                continue

            # Nur vollständige Beobachtungen verwenden. Weniger als 10 Jahre
            # (40 Quartale) sind zu wenig für einen verlässlichen Test.
            data = cdf[cols].dropna()
            if data.shape[0] < 40:
                coint_rows.append(
                    {
                        "Country": country,
                        "Model": prop,
                        "Endog_Vars": ";".join(cols),
                        "Sample_Start": np.nan,
                        "Sample_End": np.nan,
                        "N_Obs": int(data.shape[0]),
                        "Chosen_Lag_VAR": np.nan,
                        "Chosen_k_ar_diff": np.nan,
                        "Cointegrating_Ranks": 0,
                        "Supports_VECM": False,
                    }
                )
                continue

            # Optimale Lag-Anzahl per AIC bestimmen, max. 6 Quartale.
            # k_ar_diff ist die Lag-Anzahl im VECM (in Differenzen) und
            # liegt immer um 1 unter der Lag-Anzahl im VAR (in Niveaus).
            try:
                lag_res = select_order(data, maxlags=6, deterministic="co")
                lag_var = safe_int(lag_res.aic, fallback=2)
            except Exception:
                lag_var = 2
            lag_var = max(lag_var, 1)
            k_ar_diff = max(lag_var - 1, 1)

            # Johansen-Trace-Test: prüft, wie viele langfristige Beziehungen
            # zwischen den Variablen bestehen. Rang > 0 = VECM ist anwendbar.
            try:
                rank_res = select_coint_rank(
                    data,
                    det_order=0,
                    k_ar_diff=k_ar_diff,
                    method="trace",
                    signif=0.05,
                )
                rank = int(rank_res.rank)
            except Exception:
                rank = 0

            lag_rows.append(
                {
                    "Country": country,
                    "Model": prop,
                    "Endog_Vars": ";".join(cols),
                    "Chosen_Lag_VAR": lag_var,
                    "Chosen_k_ar_diff": k_ar_diff,
                    "N_Obs": int(data.shape[0]),
                }
            )
            coint_rows.append(
                {
                    "Country": country,
                    "Model": prop,
                    "Endog_Vars": ";".join(cols),
                    "Sample_Start": data.index.min().strftime("%Y-%m-%d"),
                    "Sample_End": data.index.max().strftime("%Y-%m-%d"),
                    "N_Obs": int(data.shape[0]),
                    "Chosen_Lag_VAR": lag_var,
                    "Chosen_k_ar_diff": k_ar_diff,
                    "Cointegrating_Ranks": rank,
                    "Supports_VECM": rank > 0,
                }
            )

    pd.DataFrame(coint_rows).sort_values(["Country", "Model"]).to_csv(COINT_PATH, index=False)
    pd.DataFrame(lag_rows).sort_values(["Country", "Model"]).to_csv(LAG_PATH, index=False)
    print(f"Saved cointegration results: {COINT_PATH}")
    print(f"Saved lag selection: {LAG_PATH}")


if __name__ == "__main__":
    main()

